# Contributing

This project is no longer in active development. See #4259 for details.

Please consider contributing to the [visjs community](https://github.com/visjs)!
